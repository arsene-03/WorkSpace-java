
public class Q1 {

	public static void main(String[] args) {
		byte a = 22;
		byte b = 4;
		
		char c = (char)(a*b);
		
		System.out.println(c);

	}

}
